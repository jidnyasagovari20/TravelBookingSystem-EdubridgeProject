package com.example.demo.exception;

public class UserIDNotFoundException extends Exception {

	public UserIDNotFoundException(String message) {
		super(message);
	}
	}
