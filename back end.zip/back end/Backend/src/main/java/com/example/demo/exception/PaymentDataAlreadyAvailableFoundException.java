package com.example.demo.exception;


public class PaymentDataAlreadyAvailableFoundException extends Exception {

	public PaymentDataAlreadyAvailableFoundException(String message) {
		super(message);
	}
}
