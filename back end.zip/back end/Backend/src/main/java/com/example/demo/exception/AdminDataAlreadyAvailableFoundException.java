package com.example.demo.exception;


public class AdminDataAlreadyAvailableFoundException extends Exception {

	public AdminDataAlreadyAvailableFoundException(String message) {
		super(message);
	}
}
