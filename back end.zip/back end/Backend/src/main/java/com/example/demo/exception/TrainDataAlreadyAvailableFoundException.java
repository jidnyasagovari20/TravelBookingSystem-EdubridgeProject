package com.example.demo.exception;


public class TrainDataAlreadyAvailableFoundException extends Exception {

	public TrainDataAlreadyAvailableFoundException(String message) {
		super(message);
	}
}
