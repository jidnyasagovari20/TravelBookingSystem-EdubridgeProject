package com.example.demo.exception;


public class BusDataAlreadyAvailableFoundException extends Exception {

	public BusDataAlreadyAvailableFoundException(String message) {
		super(message);
	}
}
