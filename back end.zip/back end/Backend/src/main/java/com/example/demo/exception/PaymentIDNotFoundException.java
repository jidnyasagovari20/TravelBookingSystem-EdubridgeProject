package com.example.demo.exception;

public class PaymentIDNotFoundException extends Exception {

	public PaymentIDNotFoundException(String message) {
		super(message);
	}
	}
