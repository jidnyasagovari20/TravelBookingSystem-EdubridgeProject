package com.example.demo.exception;


public class BookingDataAlreadyAvailableFoundException extends Exception {

	public BookingDataAlreadyAvailableFoundException(String message) {
		super(message);
	}
}
