package com.example.demo.exception;

public class TrainIDNotFoundException extends Exception {

	public TrainIDNotFoundException(String message) {
		super(message);
	}
	}
