package com.example.demo.exception;

public class BookingIDNotFoundException extends Exception {

	public BookingIDNotFoundException(String message) {
		super(message);
	}
	}
