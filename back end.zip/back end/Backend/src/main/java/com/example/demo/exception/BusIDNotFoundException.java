package com.example.demo.exception;

public class BusIDNotFoundException extends Exception {

	public BusIDNotFoundException(String message) {
		super(message);
	}
	}
